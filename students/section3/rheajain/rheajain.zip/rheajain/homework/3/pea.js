
$(document).ready(function(){
	$( ".carrot" ).draggable();
	$( ".pea" ).draggable();
});
