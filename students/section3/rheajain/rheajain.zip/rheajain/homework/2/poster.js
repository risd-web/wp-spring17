
$(document).ready(function(){

	$('.cb').click(function(){
		$('.eye, .eye2').toggleClass('spin');
	});

});