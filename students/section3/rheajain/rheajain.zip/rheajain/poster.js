$(document).ready(function(){

	$(eye)








});