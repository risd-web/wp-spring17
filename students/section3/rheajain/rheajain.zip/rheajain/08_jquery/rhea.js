console.log("hello.js")

$(document).ready(function(){


	$('.button').click(function(){
		console.log("test-button");
		$('.hi').fadeOut(1200);

	});

});