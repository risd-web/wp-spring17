$(document).ready(function(){
	
	$('h1').click(function(){
		$('.moods').slideToggle();
	});

});